import java.sql.*;

public class CustomerDAO {
    private static final String URL = "jdbc:mysql://localhost:3306/movie_rental";
    private static final String USER = "root";
    private static final String PASSWORD = "hellokitty987$A"; // Replace with your actual password

    // Method to insert a customer
    public static void insertCustomer(String firstName, String lastName, String email, String phone) {
        try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = con.prepareStatement("INSERT INTO customers (first_name, last_name, email, phone) VALUES (?, ?, ?, ?)")) {
            stmt.setString(1, firstName);
            stmt.setString(2, lastName);
            stmt.setString(3, email);
            stmt.setString(4, phone);
            stmt.executeUpdate();
            System.out.println("Customer added successfully!");
        } catch (SQLException e) {
            System.out.println("Error adding customer: " + e.getMessage());
        }
    }

    // Method to delete all customers
    public static void deleteAllCustomers() {
        try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = con.createStatement()) {

            // Delete all rentals related to customers
            int rentalsDeleted = stmt.executeUpdate("DELETE FROM rentals");
            System.out.println("Deleted " + rentalsDeleted + " rental(s) from the database.");

            // Now, delete all customers
            int customersDeleted = stmt.executeUpdate("DELETE FROM customers");
            System.out.println("Deleted " + customersDeleted + " customer(s) from the database.");

        } catch (SQLException e) {
            System.out.println("Error deleting customers: " + e.getMessage());
        }
    }

    // Method to display all customers
    public static void displayAllCustomers() {
        // Your implementation to display customers
    }
}
