import java.sql.Connection;
import java.sql.DriverManager;

import com.mysql.cj.xdevapi.Statement;

public class PaymentDAO {

    public static void insertPayment(int rentalId, double amount, String paymentDate) {
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/movie_rental", "root", "hellokitty987$A");
            java.sql.Statement stmt = con.createStatement();

            String sql = "INSERT INTO payments (rental_id, amount, payment_date) " +
                         "VALUES (" + rentalId + ", " + amount + ", '" + paymentDate + "')";
            stmt.executeUpdate(sql);
            System.out.println("Payment inserted successfully!");

            stmt.close();
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
