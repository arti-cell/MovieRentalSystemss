import java.util.Scanner;

public class MovieSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice = 0;

        do {
            System.out.println("\nMovie Rental System");
            System.out.println("1. Add Customer");
            System.out.println("2. Add Movie");
            System.out.println("3. Rent a Movie");
            System.out.println("4. Make a Payment");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            
            // Check if input is an integer
            if (scanner.hasNextInt()) {
                choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        // Assuming methods to input customer details
                        scanner.nextLine(); // Clear the buffer
                        System.out.print("Enter first name: ");
                        String firstName = scanner.nextLine();
                        System.out.print("Enter last name: ");
                        String lastName = scanner.nextLine();
                        System.out.print("Enter email: ");
                        String email = scanner.nextLine();
                        System.out.print("Enter phone: ");
                        String phone = scanner.nextLine();
                        CustomerDAO.insertCustomer(firstName, lastName, email, phone);
                        break;
                    case 2:
                        scanner.nextLine(); // Clear the buffer
                        System.out.print("Enter movie title: ");
                        String title = scanner.nextLine();
                        System.out.print("Enter movie genre: ");
                        String genre = scanner.nextLine();
                        System.out.print("Enter release year: ");
                        int releaseYear = scanner.nextInt();
                        System.out.print("Enter rating: ");
                        double rating = scanner.nextDouble();
                        MovieDAO.insertMovie(title, genre, releaseYear, rating);
                        break;
                    case 3:
                        // Assuming IDs are known
                        RentalDAO.insertRental(1, 1, "2024-10-01", null);
                        break;
                    case 4:
                        PaymentDAO.insertPayment(1, 3.99, "2024-10-01");
                        break;
                    case 5:
                        System.out.println("Exiting...");
                        break;
                    default:
                        System.out.println("Invalid choice! Please try again.");
                }
            } else {
                System.out.println("Please enter a valid number.");
                scanner.next(); // Clear the invalid input
            }
        } while (choice != 5);

        scanner.close();
    }
} 