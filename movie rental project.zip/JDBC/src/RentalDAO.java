import java.sql.Connection;
import java.sql.DriverManager;

import com.mysql.cj.xdevapi.Statement;

public class RentalDAO {

    public static void insertRental(int customerId, int movieId, String rentalDate, String returnDate) {
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/movie_rental", "root", "hellokitty987$A");
            java.sql.Statement stmt = con.createStatement();

            String sql = "INSERT INTO rentals (customer_id, movie_id, rental_date, return_date) " +
                         "VALUES (" + customerId + ", " + movieId + ", '" + rentalDate + "', '" + returnDate + "')";
            ((java.sql.Statement) stmt).executeUpdate(sql);
            System.out.println("Rental inserted successfully!");

            stmt.close();
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}