import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import com.mysql.cj.xdevapi.Statement;

public class MovieDAO {

    public static void insertMovie(String title, String genre, int releaseYear, double rating) {
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/movie_rental", "root", "hellokitty987$A");
            java.sql.Statement stmt = con.createStatement();

            String sql = "INSERT INTO movies (title, genre, release_year, rating) " +
                         "VALUES ('" + title + "', '" + genre + "', " + releaseYear + ", " + rating + ")";
            stmt.executeUpdate(sql);
            System.out.println("Movie inserted successfully!");

            stmt.close();
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void displayMovies() {
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/movie_rental_db", "root", "hellokitty987$A");
            java.sql.Statement stmt = con.createStatement();

            String sql = "SELECT * FROM movies";
            ResultSet rs = stmt.executeQuery(sql);

            System.out.println("Movies List:");
            while (rs.next()) {
                int id = rs.getInt("movie_id");
                String title = rs.getString("title");
                String genre = rs.getString("genre");
                int year = rs.getInt("release_year");
                double rating = rs.getDouble("rating");

                System.out.println(id + ": " + title + " (" + genre + ", " + year + ", Rating: " + rating + ")");
            }

            stmt.close();
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

	public static void deleteMovie(int movieId) {
		// TODO Auto-generated method stub
		
	}
}
