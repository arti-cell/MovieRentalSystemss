import java.sql.*;

public class MovieRental {

    public static void main(String[] args) {
        try {
            // Load the MySQL JDBC driver (for MySQL 8+)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish a connection to the MySQL database
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/movie_rental", "root", "hellokitty987$A");

            // Create a statement object to execute SQL queries
            Statement stmt = con.createStatement();
            System.out.println("Inserting records...");

            // Insert data into "customers" table
            String sql = "INSERT INTO customers (first_name, last_name, email, phone) " +
                         "VALUES ('John', 'Doe', 'john.doe@example.com', '1234567890'), " +
                         "       ('Jane', 'Smith', 'jane.smith@example.com', '9876543210')";
            stmt.executeUpdate(sql);  // Execute the insert query

            // Insert data into "movies" table
            sql = "INSERT INTO movies (title, genre, release_year, rating) " +
                  "VALUES ('Inception', 'Sci-Fi', 2010, 8.8), " +
                  "       ('The Godfather', 'Crime', 1972, 9.2)";
            stmt.executeUpdate(sql);

            // Insert data into "rentals" table
            sql = "INSERT INTO rentals (customer_id, movie_id, rental_date, return_date) " +
                  "VALUES (1, 1, '2024-10-01', '2024-10-03'), " +
                  "       (2, 2, '2024-10-02', NULL)";
            stmt.executeUpdate(sql);

            // Insert data into "payments" table
            sql = "INSERT INTO payments (rental_id, amount, payment_date) " +
                  "VALUES (1, 3.99, '2024-10-01'), " +
                  "       (2, 4.99, '2024-10-02')";
            stmt.executeUpdate(sql);

            System.out.println("Records inserted successfully!");

            // Close the connection and statement objects
            stmt.close();
            con.close();

        } catch (Exception e) {
            // Print any exceptions
            System.out.println(e);
        }
    }
}
